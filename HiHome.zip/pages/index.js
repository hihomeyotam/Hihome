
export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '100px' }}>
      <h1>ברוכים הבאים ל-HiHome!</h1>
      <p>אתר נדל"ן חכם וידידותי.</p>
    </div>
  );
}
